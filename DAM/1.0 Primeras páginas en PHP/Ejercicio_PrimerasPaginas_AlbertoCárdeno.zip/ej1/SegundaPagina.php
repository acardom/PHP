<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Saludo</title>
</head>
<body>
    <?php
        // Mensaje de saludo
        echo "<h1>¡Hola, mundo!</h1>";
    ?>
    <!-- enlace al index.php -->
    <p>Regresa a la <a href="index.php">página de inicio</a>.</p>
</body>
</html>
