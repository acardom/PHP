<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Página de Inicio</title>
</head>
<body>
    <!-- texto principal -->
    <h1>Hola</h1>
    <p>Para ver el saludo, haz clic en el siguiente enlace:</p>
    <!-- enlace al otro php -->
    <a href="SegundaPagina.php">Cambiar pagina</a>
</body>
</html>
